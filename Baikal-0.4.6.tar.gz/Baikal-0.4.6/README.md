Baïkal
======

This is the source repository for the Baïkal CalDAV and CardDAV server.

* Go to [baikal-server.com][1] to get more information about this project.
* Head to [sabre.io/baikal][2] for information about installation, upgrading
  and troubleshooting.

Upgrading from 0.2.7
--------------------

Please follow [the upgrade instructions][5].

Credits
-------

Bäikal is developed by [Jérôme Schneider][3] from [Net Gusto][3] and [fruux][4].
Many thanks to Daniel Aleksandersen (@zcode) for greatly improving the quality of the project page (http://baikal-server.com).

[1]: http://baikal-server.com/
[2]: http://sabre.io/baikal/
[3]: http://netgusto.com/
[4]: https://fruux.com/
[5]: http://sabre.io/baikal/upgrade/
